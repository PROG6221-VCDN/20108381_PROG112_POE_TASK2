﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalBudgetPlanner
{
    class UserBudget
    {
        public static Budget currentBudget;//class to store a static object of buget for the user to push to, pull from and edit
    }
}
